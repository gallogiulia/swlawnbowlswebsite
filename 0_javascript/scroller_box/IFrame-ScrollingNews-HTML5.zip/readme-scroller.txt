
NEWS IFRAME ADD-ON

----------------------------------------------

UNZIP THIS FILE AND THEN OPEN THE help-ScrollingNews.html TO GET STARTED.

----------------------------------------------

COPYRIGHT 2013 � Allwebco Design Corporation
Unauthorized use or sale of this script is strictly prohibited by law.
You are authorized to use this on any Allwebco template, website or any
template from another company. You are also authorized to modify all
included files for this site use. 


Help for this add-on can be found at:

http://www.allwebco-templates.com/support/S_script_newsfeed.htm

http://www.allwebco-templates.com/support/S_script_IFrame-NewsScroll.htm



